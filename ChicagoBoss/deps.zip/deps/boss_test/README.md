# boss_test

This is just a shared module for testing with
[ChicagoBoss](http://github.com/ChicagoBoss/ChicagoBoss)
