-module(boss_record_lib_test).
-include_lib("proper/include/proper.hrl").
-include_lib("eunit/include/eunit.hrl").

% Placeholder for now
